//
//  RedViewController.swift
//  onesignernotificationservicesextention
//
//  Created by Vaibhav on 08/03/18.
//  Copyright © 2018 Vaibhav. All rights reserved.
//

import UIKit

class RedViewController: UIViewController {

    var receivedURL: String?
    
    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if receivedURL != nil {
            loadURL(url: receivedURL!)
        }
    }
    
    func loadURL(url: Any) {
        
        guard let URL = URL(string: url as! String)
            
            else { return }
        
        webView.loadRequest(URLRequest(url: URL))
    }
}
