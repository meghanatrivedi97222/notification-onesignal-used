//
//  ViewController.swift
//  onesignernotificationservicesextention
//
//  Created by Vaibhav on 08/03/18.
//  Copyright © 2018 Vaibhav. All rights reserved.
//

import UIKit
import OneSignal

class ViewController: UIViewController,OSPermissionObserver,OSSubscriptionObserver {
    
    
    
  /* @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var allowNotificationsSwitch: UISwitch!
    @IBOutlet weak var setSubscriptionLabel: UILabel!
    @IBOutlet weak var registerForPushNotificationsButton: UIButton!*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       /* let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
        let isSubscribed = status.subscriptionStatus.subscribed
        
        if isSubscribed == true {
            allowNotificationsSwitch.isOn = true
            allowNotificationsSwitch.isUserInteractionEnabled = true
            registerForPushNotificationsButton.backgroundColor = UIColor.green
            registerForPushNotificationsButton.isUserInteractionEnabled = false
        }
        OneSignal.add(self as OSPermissionObserver)
        OneSignal.add(self as OSSubscriptionObserver)*/
    }
    
  /* func displaySettingsNotification() {
        let message = NSLocalizedString("Please turn on notifications by going to Settings > Notifications > Allow Notifications", comment: "Alert message when the user has denied access to the notifications")
        let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: "Alert button to open Settings"), style: .`default`, handler: { action in
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(URL(string: UIApplicationOpenSettingsURLString)!, options: [:], completionHandler: nil)
            } else {
                // Fallback on earlier versions
            }
        });
        self.displayAlert(title: message, message: "OneSignal Example", actions: [UIAlertAction.okAction(), settingsAction]);
    }*/
    
   /* func displayError(withMessage message : String) {
        let action = UIAlertAction(title: "Ok", style: .cancel, handler: nil);
        self.displayAlert(title: "An Error Occurred", message: message, actions: [action])
    }*/
    
   /* func changeLogoutAnimationState(_ animating : Bool) {
        UIView.animate(withDuration: 0.15, animations: {
            self.view.layoutIfNeeded();
        }) { (completed) in
            if (completed && !animating) {
               // self.logoutEmailActivityIndicatorView.stopAnimating();
            }
        }
    }*/
    
 /*  func displayAlert(title : String, message: String, actions: [UIAlertAction]) {
        let controller = UIAlertController(title: title, message: message, preferredStyle: .alert);
        actions.forEach { controller.addAction($0) };
        self.present(controller, animated: true, completion: nil);
    }*/
    
    func onOSPermissionChanged(_ stateChanges: OSPermissionStateChanges!) {
      /*  if stateChanges.from.status == OSNotificationPermission.notDetermined {
            if stateChanges.to.status == OSNotificationPermission.authorized {
                registerForPushNotificationsButton.backgroundColor = UIColor.green
                registerForPushNotificationsButton.isUserInteractionEnabled = false
                allowNotificationsSwitch.isUserInteractionEnabled = true
            } else if stateChanges.to.status == OSNotificationPermission.denied {
                displaySettingsNotification()
            }
        } else if stateChanges.to.status == OSNotificationPermission.denied { // DENIED = NOT SUBSCRIBED
            registerForPushNotificationsButton.isUserInteractionEnabled = true
            allowNotificationsSwitch.isUserInteractionEnabled = false
        }*/
    }
    
    func onOSSubscriptionChanged(_ stateChanges: OSSubscriptionStateChanges!) {
       /* if stateChanges.from.subscribed && !stateChanges.to.subscribed { // NOT SUBSCRIBED != DENIED
            allowNotificationsSwitch.isOn = false
            setSubscriptionLabel.text = "Set Subscription OFF"
            registerForPushNotificationsButton.backgroundColor = UIColor.red
        } else if !stateChanges.from.subscribed && stateChanges.to.subscribed {
            allowNotificationsSwitch.isOn = true
            allowNotificationsSwitch.isUserInteractionEnabled = true
            setSubscriptionLabel.text = "Set Subscription ON"
            registerForPushNotificationsButton.backgroundColor = UIColor.green
            registerForPushNotificationsButton.isUserInteractionEnabled = false
        }*/
    }
    
   /* func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      // textField.resignFirstResponder();
        
        return true;
    }*/
    
   /* @IBAction func onRegisterForPushNotificationsButton(_ sender: UIButton) {
      /* let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
        let hasPrompted = status.permissionStatus.hasPrompted
        if hasPrompted == false {
            OneSignal.promptForPushNotifications(userResponse: { accepted in
                if accepted == true {
                    print("User accepted notifications: \(accepted)")
                } else {
                    print("User accepted notifications: \(accepted)")
                }
            })
        } else {
            displaySettingsNotification()
        }*/
    }*/
  
  /*  @IBAction func onAllowNotificationsSwitch(_ sender: UISwitch) {
      /* if !allowNotificationsSwitch.isOn {
          //  OneSignal.setSubscription(false)
        } else {
           // OneSignal.setSubscription(true)
        }*/
    }*/
    
}

extension UIAlertAction {
    static func okAction() -> UIAlertAction {
        return UIAlertAction(title: NSLocalizedString("OK", comment: "Alert OK button"), style: .cancel, handler: nil);
    }
}



