//
//  GreenViewController.swift
//  onesignernotificationservicesextention
//
//  Created by Vaibhav on 08/03/18.
//  Copyright © 2018 Vaibhav. All rights reserved.
//

import UIKit

class GreenViewController: UIViewController {
     var receivedURL: String?
     @IBOutlet weak var webView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        if receivedURL != nil {
            loadURL(url: receivedURL!)
        }
    }
    func loadURL(url: Any) {
        
        guard let URL = URL(string: url as! String)
            
            else { return }
        
        webView.loadRequest(URLRequest(url: URL))
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
